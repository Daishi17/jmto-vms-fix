<tr>
    <th>Dokumen Penawaran</th>
    <th>
        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#buka_dokumen_penawaran">
            <i class="fa fa-folder-open" aria-hidden="true"></i> Upload Dokumen Penawaran
        </button>
    </th>
</tr>

<tr>
    <th>Dokumen Penawaran</th>
    <th>
        <label for="" class="badge bg-secondary">Tahap Sudah Selesai</label>
    </th>
</tr>

<tr>
    <th>Upload Dokumen Penawaran</th>
    <th>
        <button type="button" class="btn btn-sm btn-danger" disabled>
            <i class="fa fa-folder-close" aria-hidden="true"></i> Anda Telah Gugur Dalam Pengadaan Ini
        </button>
    </th>
</tr>