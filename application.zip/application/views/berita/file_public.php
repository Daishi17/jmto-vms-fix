<script>
    $('#tbl_berita').DataTable()
</script>