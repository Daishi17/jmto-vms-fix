<script src="<?= base_url('js_folder/registrasi/file_public.js')?>"></script>
<script src="<?= base_url('js_folder/identitas/file_public.js')?>"></script>